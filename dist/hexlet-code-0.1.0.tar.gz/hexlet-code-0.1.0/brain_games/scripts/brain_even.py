#!/usr/bin/env python

from brain_games.games.play_brain_even import play_brain_even


def main():
    print('Welcome to the Brain Games!')
    play_brain_even()

if __name__ == '__main__':
    main()
